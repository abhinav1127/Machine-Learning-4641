To run the code contained in this file, ensure that python 2.7 is downloaded and that you have the following libraries: sklearn, matplotlib, itertools, pandas, numpy, and copy.

All of the data and files are included in the same folder. Each python file represents an algorithm paired with a particular dataset. The shorthand stand for:
CC: Credit Card Dataset
Pima: Pima Indians Diabetes Dataset
DT: Decision Tree
KNN: k-Nearest Neighbors
NN: Neural Network
SVM: Support Vector Machine

