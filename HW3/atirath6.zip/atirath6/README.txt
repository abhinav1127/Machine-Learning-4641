To run the code contained in this file, ensure that python 2.7 is downloaded and that you have the following libraries: sklearn, matplotlib, itertools, pandas, numpy, and copy.

All of the data and files are included in the same folder.

AnalysisCC.py is the file in which we analyze the credit card data

AnalysisPima.py is the file in which we analyze the Pima Indians Diabetes data

